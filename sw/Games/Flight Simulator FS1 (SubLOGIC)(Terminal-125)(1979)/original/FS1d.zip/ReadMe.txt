https://forum.vcfed.org/index.php?threads/fs1-for-exidy-sorcerer.1237688/

The manual is here:
https://archive.org/details...
Some of the key commands have been moved to the keypad:
Keypad controls:
2 pitch up
8 pitch down
4 roll left
6 roll right
5 roll neutral
9 throttle up
7 throttle down
- gear up
� gear down
+ radar view
* forward view
= drop bomb

original port to sorcerer:
https://www.classic-computers.org.nz/blog/2017-01-23-software-for-real-sorcerers.htm
