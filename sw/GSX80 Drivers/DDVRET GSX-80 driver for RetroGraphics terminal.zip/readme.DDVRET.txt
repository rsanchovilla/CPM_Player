The DDVRET Driver
=================
Martin Hepperle, June 2020

The first issue of the GSX-80 Programmers Manual contained 
incomplete source file listings of the driver DDVRET.
These were intended to be used as a starting point for driver developers.

(Note: the Retrographics Video Terminal supports text mode escape sequences.
Additionally, it provides a graphics mode with Tektronix emulation so that 
this driver outputs Tektronix control sequences.)

These source files had been written for the RATFOR preprocessor.
The DDVRET.RAT source code is passed through RATFOR to generate DDVRET.FOR.
DDVRET.FOR is then compiled by a FORTRAN compiler and finally linked with 
the FORTRAN runtime libraries. I used the Microsft F80 compiler.

I was unable to find a ready-made RATFOR for CP/M which could handle the
large number of defines as well as the syntax of the define statements
(with quotation marks).
Therefore I selected a more recent source for the RATFOR preprocessor and
compiled my own variant for Windows 32 and 64 bit.

The main difficulty was that the code assumed 16-bit integers for 
storage of character arrays and that subroutines were using fixed 
array dimensions of 100 for passed parameters.
Thus, the compiler had to be instructed to assume INTEGER*2 as the default 
integer type and to perform no array bounds checking.

Changes were also required in the file open and close routines which maintain
a stack of open files (for the include statement).

As a last modifications the arrays for 'define' statements had to be increased
to accomodate the large number and long names of the defines in the DDVRET 
source and DDCOM include file.

With the resulting executables it is now possible to transform the DDVRET.RAT
files on a Windows system into FORTRAN.

After RATFOR was working, I was able to correct most typos in the
DDVRET.RAT source code. It is quite likely that I have still overlooked a
few typos in the file ddvret.rat..

Final Remarks
==============
Some files are missing from the manual:
- most notably the include file 'ddcom' which not only cntains the
standard RATFOR defines but also all the GSX-specific defines.
This file has been recreated.
- Furthermore twelve support routines were not printed in the manual.
They were probably written in assembler code and could be replaced with 
either FORTRAN or assembler code.
So far, I have only provided skeleton routines to satisfy the linker.
In order to obtain a working driver, these routines at the end of the DDVRET.RAT
file would have to be fleshed out.
- the Microsoft FORTRAN compiler cannot generate the parameter passing conventions 
required by GSX. A thin assembler interface layer VRET.MAC is needed as an
interface between FORTRAN and the GDOS.
