DDMF.PRL GSX-80 driver
======================

Created by Martin Hepperle, 2020

DDMF is a simple Metafile file driver for GSX-80 under CP/M 2.2.
It supports output to a GEM Metafile which can be imported by
some CP/M programs. It can also be read by drawing programs 
like Corel Draw on Windows.
The name of the Metafile is always "GSX.GEM".

The source code is included and the file MF.MAC can be assembled
with the Microsoft M80 assembler whereas the file DDMF.FOR requires
the Microsoft F80 V3.44 compiler.
The object files have to be linked with Digital Research LINK V1.3
to produce the final PRL file. You cannot use Microsoft L80 for this.

The official convention is that the entry in ASSIGN.SYS should have 
an ID number between 31 and 40 to define a Metafile. But this does 
not really matter. 
To avoid recompilation of DEMOGRAF and other programs I assigned it
a screen ID of 1 during development and testing.

The CBASIC Program G.BAS can be used to test the driver.
The compile, link, add the GSX loader and execute sequence would be:

CB80 G
LK80 G
GENGRAF G
G

The result should be a file GSX.GEM.

Notes:
- You can use this program for any non-commercial application.
- This driver was based on the skeleton of the DDXTEK driver
  which was written by Udo Munk in 2014.


GEMVIEW
=======
This is a small tool to read GEM metafiles and display them using another GSX driver.

Command line:

GEMVIEW [-D 1|2] [-R] [-O id] file.gem

-D n	set debug level to 1 or 2
-R	redirect RDR, PUN, LST to the console (e.d. for DDHP7470 driver
-O id	select driver with id from ASSIGN.SYS file
file.gem	the metafile to read, complete with extension
