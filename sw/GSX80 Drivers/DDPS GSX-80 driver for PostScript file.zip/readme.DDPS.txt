DDPS.PRL GSX-80 driver
======================

Created by Martin Hepperle, 2020

DDPS is a simple Postscript file driver for GSX-80 under CP/M 2.2.
It supports output to a multi-page black and white Postscript file 
which can printed on a Postscript printer.
It can also be read by drawing programs like Corel Draw.
You can also display, print or convert it to PDF with Ghostscript 
and similar Postscript interpreters.
The name of the Postscript file is always "GSX.PS".

The source code is included and the file PS.MAC can be assembled
with the Microsoft M80 assembler and the file DDPS.FOR with 
the Microsoft F80 V3.44 compiler.
The object files have to be linked with Digital Research LINK V1.3
to produce the final PRL file. You cannot use Microsoft L80 for this.

The official convention is that the entry in ASSIGN.SYS should have 
an ID number between 31 and 40 to define a Metafile. But this does 
not really matter. 
To avoid recompilation of DEMOGRAF and other programs I assigned it
a screen ID of 1 during development and testing.

The CBASIC Program G.BAS can be used to test the driver.
The compile, link, attach GSX loader and execute sequence would be:

CB80 G
LK80 G
GENGRAF G
G

The result should be a file GSX.PS.

Notes:
- The text output functions may crash a Postscript interpreter
  if the text contains reserved characters.
  Currently only '(', ')' and, '\' are escaped into octal codes.
- You can use this program for any non-commercial application.
- This driver was based on the skeleton of the DDXTEK driver
  which was written by Udo Munk in 2014.
