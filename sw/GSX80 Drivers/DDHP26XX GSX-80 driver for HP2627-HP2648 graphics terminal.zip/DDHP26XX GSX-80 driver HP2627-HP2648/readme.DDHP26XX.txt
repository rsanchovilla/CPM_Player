DDHP2627.PRL GSX-80 driver
DDHP2648.PRL GSX-80 driver
==========================
Created by Martin Hepperle, 2020

DDHP2627 and DDHP2648 are terminal display drivers for GSX-80 under CP/M 2.2.
They support the correspnding HP terminals in text and graphics modes.

The source code is included. The files HP26??.MAC can be assembled
with the Microsoft M80 assembler and the files DDHP26??.FOR with 
the Microsoft F80 V3.44 compiler.
The object files have to be linked with Digital Research LINK V1.3
to produce the final PRL file. You cannot use Microsoft L80 for this.
Submit files DDHP26??.SUB for compilation on drive B: are also included.

The official convention is that the entry in ASSIGN.SYS should have 
an ID number between 1 and 10 to define a display.

Notes:
- You can use this program for any non-commercial application.
- This driver was based on the skeleton of the DDXTEK driver
  which was written by Udo Munk in 2014.
