DDPX8.PRL GSX-80 driver
======================

Created by Martin Hepperle, 2020

DDPX8 is a simple Epson PX-8 driver for GSX-80 under CP/M 2.2.
It supports output to the 480 x 64 LCD screen of the PX-8.

The source code is included and the file PX8.MAC can be assembled
with the Microsoft M80 assembler whereas the file DDPX8.FOR compiles
with the Microsoft F80 V3.44 compiler.
The object files MUST be linked with Digital Research LINK V1.3
to produce the final PRL file. You cannot use Microsoft L80 for this.

The official convention is that the entry in ASSIGN.SYS should have 
an ID number between 1 and 10 to define a display driver. But this does 
not really matter. 
To avoid recompilation of DEMOGRAF and other programs I assigned it
a screen ID of 1 during development and testing.

The CBASIC Program G.BAS can be used to test the driver.
The compile, link, attach GSX loader and execute sequence would be:

CB80 G
LK80 G
GENGRAF G
G

Notes:
- The text output functions snap text to the raster of the 80x8 columns x rows 
  text screen of the PX-8.
- You can use this program for any non-commercial application.
- This driver was based on the skeleton of the DDXTEK driver
  which was written by Udo Munk in 2014.
